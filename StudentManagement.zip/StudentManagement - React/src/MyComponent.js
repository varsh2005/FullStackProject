import React from 'react';

export const Header = () =>{
  return <h1>Welcome to the website</h1>
};

export const Footer = () => {
  return <footer>@2025 MyCompany</footer>
}

export default function MainContent(){
  return <div>This is Main Content</div>
} 
