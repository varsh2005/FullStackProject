import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";

const baseUrl = "http://localhost:8090/students";

function App() {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [search, setSearch] = useState("");
  const [message, setMessage] = useState("");
  const initialState = {
    studId: "",
    studName: "",
    mailId: "",
    dept: "",
    courseId: "",
    courseName: "",
    courseDes: "",
    duration: "",
  };
  const [student, setStudent] = useState(initialState);

  const fetchStudents = async () => {
    try {
      const res = await axios.get(`${baseUrl}/students`);
      setStudents(res.data);
    } catch {
      showMessage("Failed to fetch students", "danger");
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  // Alerts
  const showMessage = (msg, type) => {
    setMessage({ text: msg, type });
    setTimeout(() => setMessage(""), 3000);
  };

  // Input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudent({ ...student, [name]: value });
  };

  // Save student (add/update)
  const handleSave = async (e) => {
    e.preventDefault();
    try {
      if (selectedStudent) {
        await axios.put(`${baseUrl}/students`, student);
        showMessage("Student updated", "success");
      } else {
        await axios.post(`${baseUrl}/students`, student);
        showMessage("Student added", "success");
      }
      setStudent(initialState);
      setSelectedStudent(null);
      fetchStudents();
    } catch {
      showMessage("Operation failed", "danger");
    }
  };

  // Edit student
  const handleEdit = (stud) => {
    setStudent(stud);
    setSelectedStudent(stud);
  };

  // Delete student
  const handleDelete = async (id) => {
    if (window.confirm("Delete this student?")) {
      try {
        await axios.delete(`${baseUrl}/students/${id}`);
        showMessage("Deleted successfully", "success");
        fetchStudents();
      } catch {
        showMessage("Delete failed", "danger");
      }
    }
  };

  // Filtered list
  const filtered = students.filter(
    (s) =>
      String(s.studId).includes(search) ||
      (s.studName && s.studName.toLowerCase().includes(search.toLowerCase())) ||
      (s.mailId && s.mailId.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="container mt-5">
      <div className="text-center mb-4">
        <h2 className="fw-bold">🎓 Student Management System</h2>
        <p className="text-muted">Manage student details easily</p>
      </div>

      {message && (
        <div className={`alert alert-${message.type} text-center`}>
          {message.text}
        </div>
      )}

      {/* Form */}
      <div className="card shadow-sm mb-4">
        <div className="card-header bg-primary text-white">
          {selectedStudent ? "Edit Student" : "Add Student"}
        </div>
        <div className="card-body">
          <form onSubmit={handleSave} className="row g-3">
            <div className="col-md-2">
              <input
                type="number"
                name="studId"
                placeholder="ID"
                className="form-control"
                value={student.studId}
                onChange={handleChange}
                required
                disabled={!!selectedStudent}
              />
            </div>
            <div className="col-md-3">
              <input
                type="text"
                name="studName"
                placeholder="Name"
                className="form-control"
                value={student.studName}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-md-3">
              <input
                type="email"
                name="mailId"
                placeholder="Email"
                className="form-control"
                value={student.mailId}
                onChange={handleChange}
                required
              />
            </div>
            <div className="col-md-2">
              <input
                type="text"
                name="dept"
                placeholder="Department"
                className="form-control"
                value={student.dept}
                onChange={handleChange}
              />
            </div>
            <div className="col-md-2">
              <input
                type="number"
                name="courseId"
                placeholder="Course ID"
                className="form-control"
                value={student.courseId}
                onChange={handleChange}
              />
            </div>
            <div className="col-md-3">
              <input
                type="text"
                name="courseName"
                placeholder="Course Name"
                className="form-control"
                value={student.courseName}
                onChange={handleChange}
              />
            </div>
            <div className="col-md-3">
              <input
                type="text"
                name="courseDes"
                placeholder="Course Description"
                className="form-control"
                value={student.courseDes}
                onChange={handleChange}
              />
            </div>
            <div className="col-md-2">
              <input
                type="text"
                name="duration"
                placeholder="Duration"
                className="form-control"
                value={student.duration}
                onChange={handleChange}
              />
            </div>
            <div className="col-12 text-end">
              <button type="submit" className="btn btn-success me-2">
                {selectedStudent ? "Update" : "Add"}
              </button>
              {selectedStudent && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => {
                    setStudent(initialState);
                    setSelectedStudent(null);
                  }}
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>
      </div>

      {/* Search */}
      <div className="input-group mb-3 shadow-sm">
        <input
          type="text"
          className="form-control"
          placeholder="🔍 Search by ID, Name, or Email"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Table */}
      <div className="table-responsive shadow-sm">
        <table className="table table-striped table-hover text-center">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Dept</th>
              <th>Course ID</th>
              <th>Course Name</th>
              <th>Course Desc</th>
              <th>Duration</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length > 0 ? (
              filtered
                .filter((s) => s.studId && s.studId !== 0)
                .map((s) => (
                  <tr key={s.studId}>
                    <td>{s.studId}</td>
                    <td>{s.studName}</td>
                    <td>{s.mailId}</td>
                    <td>{s.dept}</td>
                    <td>{s.courseId}</td>
                    <td>{s.courseName}</td>
                    <td>{s.courseDes}</td>
                    <td>{s.duration}</td>
                    <td>
                      <button
                        className="btn btn-sm btn-warning me-1"
                        onClick={() => handleEdit(s)}
                      >
                        ✏ Edit
                      </button>
                      <button
                        className="btn btn-sm btn-danger"
                        onClick={() => handleDelete(s.studId)}
                      >
                        🗑 Delete
                      </button>
                    </td>
                  </tr>
                ))
            ) : (
              <tr>
                <td colSpan="9" className="text-muted">
                  No students found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default App;