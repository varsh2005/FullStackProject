package com.varsha.StudentManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.varsha.StudentManagement.model.Student;
import com.varsha.StudentManagement.service.StudentService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/students")
public class StudentController {
	
	@Autowired
	StudentService service;

	@GetMapping("/students")
	public List<Student> getStudents(){
		return service.getStudents();
	}
	
	@GetMapping("/students/{studId}")
	public Student getStudentById(@PathVariable int id){ 
		return service.getStudentById(id);
	}
	
	@PostMapping("/students")
	public void addStudents(@RequestBody Student stud) {
		service.addStudents(stud);
	}
	
	@PutMapping("/students")
	public void updateStudents(@RequestBody Student stud) {
		service.updateStudents(stud);
	}
	
	@DeleteMapping("/students/{studId}")
	public void deleteStudent(@PathVariable int studId) {
		service.deleteStudent(studId);
	}
	
}
