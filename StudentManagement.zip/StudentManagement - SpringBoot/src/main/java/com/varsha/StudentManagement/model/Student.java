package com.varsha.StudentManagement.model;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Component
@Entity
public class Student {

	@Id
	private int studId;
	private String studName;
	private String mailId;
	private String dept;
	private int courseId;
	private String courseName;
	private String courseDes;
	private String duration;
	
	public int getStudId() {
		return studId;
	}
	public String getStudName() {
		return studName;
	}
	public String getMailId() {
		return mailId;
	}
	public String getDept() {
		return dept;
	}
	public int getCourseId() {
		return courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public String getCourseDes() {
		return courseDes;
	}
	public String getDuration() {
		return duration;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public void setCourseDes(String courseDes) {
		this.courseDes = courseDes;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	
	public Student() {
		
	}
	
	public Student(int studId, String studName, String mailId, String dept, int courseId, String courseName,
			String courseDes, String duration) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.mailId = mailId;
		this.dept = dept;
		this.courseId = courseId;
		this.courseName = courseName;
		this.courseDes = courseDes;
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", mailId=" + mailId + ", dept=" + dept
				+ ", courseId=" + courseId + ", courseName=" + courseName + ", courseDes=" + courseDes + ", duration="
				+ duration + "]";
	}
	
	
	
}
