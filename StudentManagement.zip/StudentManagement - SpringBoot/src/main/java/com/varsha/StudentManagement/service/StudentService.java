package com.varsha.StudentManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.varsha.StudentManagement.model.Student;
import com.varsha.StudentManagement.repository.StudentRepo;

@Service
public class StudentService {

	@Autowired
	StudentRepo repo;
	
	public List<Student> getStudents(){
		return repo.findAll();
	}
	
	public Student getStudentById(int id) {
		return repo.findById(id).orElse(null);
	}
	
	public void addStudents(Student stud) {
		repo.save(stud);
	}
	
	public void updateStudents(Student stud) {
		repo.save(stud);
	}
	
	public void deleteStudent(int studId) {
		repo.deleteById(studId);
	}
}
